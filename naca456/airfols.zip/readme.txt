This program is in exactly the form in which I
received it in April 1997.
I have written a revised version that includes many
new features. This program is described in my
paper numbered AIAA 2001-5235.
You may get more information at the
web site
   http://www.pdas.com
and look under Contents for NACA airfoils.

Ralph Carmichael
Public Domain Aeronautical Software
ralph@pdas.com
831-454-9754

